# ST-82-Solution
